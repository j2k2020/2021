package com.example.startTmleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartTmleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(StartTmleafApplication.class, args);
	}

}
