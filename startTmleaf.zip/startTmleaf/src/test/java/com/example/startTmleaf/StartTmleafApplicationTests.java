package com.example.startTmleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StartTmleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
